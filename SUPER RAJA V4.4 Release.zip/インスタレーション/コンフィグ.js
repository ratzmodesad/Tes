module.exports = {
  BOT_TOKEN: "TOKEN_BOT_KAMU",
    allowedDevelopers: ['7826620148'], // ID
};

/*
━━━━━━━━━━━━━━━━━━━━━━  
🔥 SUPER - RAJA 🔥  
━━━━━━━━━━━━━━━━━━━━━━  

🚀 Developer  : RajaXyrine / t.me/RajaModss
📢 Info       : @RajaChannel1
🛠️ Version    : 4.4

⚠️ **警告!** ⚠️  
📌 此机器人使用数据库。  
📌 如果您的令牌 **未在数据库中注册**，  
📌 机器人将 **无法运行**！  
📌 请确保您的令牌已注册后再使用本机器人。  

⚠️ **PERINGATAN!** ⚠️  
📌 Bot ini menggunakan database.  
📌 Jika token Anda **tidak terdaftar di database**,  
📌 bot **tidak akan berjalan**!  
📌 Pastikan token Anda sudah terdaftar sebelum menggunakan bot ini.  

━━━━━━━━━━━━━━━━━━━━━━      
  ••JANGAN HAPUS INI••
SCRIPT BY © RajaXyrine
•• recode kasih credits 
•• telegram : t.me/RajaModss

Aturan:
1. Dilarang mencopy Script ini
2. Hak cipta milik RajaXyrine.

“Dan janganlah kamu makan harta di antara kamu dengan jalan yang batil, dan janganlah kamu membunuh dirimu sendiri. Sesungguhnya Allah adalah Maha Penyayang kepadamu.” (QS. Al-Baqarah: 188)
*/